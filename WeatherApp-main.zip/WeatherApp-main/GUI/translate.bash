
cd GUI

uic settingwindow.ui > ui_settingwindow.h
uic mainwindow.ui > ui_mainwindow.h
